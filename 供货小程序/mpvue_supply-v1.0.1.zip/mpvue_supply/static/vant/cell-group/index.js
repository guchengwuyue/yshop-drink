import { create } from '../common/create';

create({
  props: {
    border: {
      type: Boolean,
      value: true
    }
  }
});
